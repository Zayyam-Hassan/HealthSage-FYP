from typing import Any, Dict

from .context_builder import build_patient_context
from .guideline_retriever import retrieve_guidelines
from .llm_engine import generate_lifestyle_plan
from .validator import validate_lifestyle_json


def generate_and_store_lifestyle_recs(patient_id: str) -> Dict[str, Any]:
    """
    Main orchestration entrypoint used by FastAPI.
    """
    context = build_patient_context(patient_id)
    guidelines = retrieve_guidelines(context, top_k=20)
    raw_json = generate_lifestyle_plan(context, guidelines)
    plan = validate_lifestyle_json(raw_json)

    return {
        "patient_id": patient_id,
        "context": context,
        "guidelines_used": [
            {
                "text": g.get("text"),
                "category": g.get("category"),
                "source": g.get("source"),
                "reference": g.get("reference"),
            }
            for g in guidelines
        ],
        "plan": plan.model_dump(),
    }

