from typing import Any, Dict, List

import json
import os
import httpx

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass


# Hosted LLM configuration (Mistral / Grok / OpenAI‑compatible).
# Override via environment variables (.env or shell):
#   LLM_BASE_URL  – full chat-completions URL
#   LLM_API_KEY   – secret key/token
#   LLM_MODEL     – model name
LLM_BASE_URL = os.getenv("LLM_BASE_URL", "https://api.mistral.ai/v1/chat/completions")
LLM_API_KEY = os.getenv("LLM_API_KEY", "")
LLM_MODEL = os.getenv("LLM_MODEL", "mistral-large-latest")

SYSTEM_PROMPT = (
    "You are a diabetes lifestyle assistant. "
    "You ONLY provide non-pharmacological, non-medication guidance "
    "about diet, exercise, sleep, stress, and smoking cessation. "
    "Never prescribe or modify medications or insulin."
)

GUIDELINE_SYSTEM_PROMPT = (
    "You are a diabetes and cardiovascular guideline expert. You cite ADA (American Diabetes Association) "
    "Standards of Medical Care in Diabetes, AHA/ACC, ESC, and similar evidence-based sources. "
    "You output only valid JSON, no markdown or extra text. "
    "Recommendations must be non-pharmacological lifestyle only (diet, activity, sleep, stress, smoking). "
    "For each guideline provide a short 'source' (e.g. ADA 2024) and a full 'reference' citation "
    "(e.g. 'ADA Standards of Medical Care in Diabetes—2024, Section 5. Diabetes Care 2024;47(Suppl 1):S77–S110')."
)

WEB_EXTRACT_SYSTEM_PROMPT = (
    "You extract diabetes lifestyle guidelines from web search results. "
    "You output only valid JSON, no markdown or extra text. "
    "Recommendations must be non-pharmacological only: diet, activity, sleep, stress, smoking. "
    "For each guideline use: \"category\" (diet, activity, sleep, behavior, general), \"text\" (one concrete recommendation), "
    "\"source\" (e.g. ADA 2024 or the page title), and \"reference\" (the exact URL from the search result for that guideline). "
    "Base your output only on the provided search results; do not invent guidelines. Prefer official ADA/diabetes.org/diabetesjournals.org sources."
)


def _call_llm(system: str, user: str) -> str:
    """Single LLM call; returns assistant message content. Raises on HTTP/API errors."""
    if not LLM_API_KEY:
        raise RuntimeError("LLM_API_KEY is not set; configure it in your environment.")
    payload: Dict[str, Any] = {
        "model": LLM_MODEL,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
    }
    headers = {
        "Authorization": f"Bearer {LLM_API_KEY}",
        "Content-Type": "application/json",
    }
    with httpx.Client(timeout=60.0) as client:
        resp = client.post(LLM_BASE_URL, headers=headers, json=payload)
        resp.raise_for_status()
        data = resp.json()
    if "choices" in data:
        content = data["choices"][0].get("message", {}).get("content", "")
    else:
        content = data.get("message", {}).get("content", "")
    return (content or "").strip()


def fetch_guidelines_for_patient(context: Dict[str, Any], top_k: int = 16) -> List[Dict[str, Any]]:
    """
    Call LLM to return evidence-based, patient-relevant lifestyle guidelines.
    Uses patient context to pick concrete recommendations. Returns multiple guidelines per category
    with "category", "text", "source", and "reference" (full citation).
    """
    parts = [
        "Patient summary (use these to choose relevant guidelines):",
        f"- Age: {context.get('age')}, Sex: {context.get('sex')}",
        f"- BMI: {context.get('BMI')}, HbA1c: {context.get('HbA1c')} %, glucose: {context.get('glucose')} mg/dL",
        f"- Blood pressure: {context.get('systolic_bp')}/{context.get('diastolic_bp')} mmHg",
        f"- Total cholesterol: {context.get('cholesterol')}",
    ]
    parts.append(
        f"\nReturn a JSON array of {max(10, top_k)} guideline snippets relevant to this patient. "
        "Include multiple guidelines per category: at least 3–4 for diet, 2–3 for activity, 1–2 for sleep, 2–3 for behavior. "
        "Each object must have: \"category\" (one of: diet, activity, sleep, behavior, general), "
        "\"text\" (one concrete, actionable recommendation), \"source\" (e.g. ADA 2024), and "
        "\"reference\" (full citation, e.g. 'ADA Standards of Medical Care in Diabetes—2024, Section 5. Diabetes Care 2024;47(Suppl 1):S77–S110'). "
        "Tailor to their numbers: e.g. if HbA1c is high, include several diet/carb and activity guidelines; "
        "if BP is high, include sodium and aerobic activity; if BMI is high, include weight and activity. "
        "Use real ADA section references where possible. Output only the JSON array, no other text or markdown."
    )
    user_prompt = "\n".join(parts)
    content = _call_llm(GUIDELINE_SYSTEM_PROMPT, user_prompt)
    if content.startswith("```"):
        content = content.strip("`")
        lines = content.splitlines()
        if lines and lines[0].strip().lower().startswith("json"):
            content = "\n".join(lines[1:])
    try:
        raw = json.loads(content)
        if isinstance(raw, list):
            guidelines = []
            for g in raw[:top_k]:
                if isinstance(g, dict) and g.get("text"):
                    guidelines.append({
                        "category": g.get("category", "general"),
                        "text": g.get("text", ""),
                        "source": g.get("source", "guideline"),
                        "reference": g.get("reference", ""),
                    })
            return guidelines if guidelines else []
        return []
    except (json.JSONDecodeError, TypeError):
        return []


def extract_guidelines_from_web_results(
    web_results: List[Dict[str, Any]],
    context: Dict[str, Any],
    top_k: int = 16,
) -> List[Dict[str, Any]]:
    """
    Take web search results (title, link, snippet) and ask the LLM to extract
    guideline recommendations with references (URLs). Returns same shape as
    fetch_guidelines_for_patient: [{category, text, source, reference}].
    """
    if not web_results:
        return []
    parts = [
        "Patient context (for relevance):",
        f"- Age: {context.get('age')}, Sex: {context.get('sex')}, BMI: {context.get('BMI')}",
        f"- HbA1c: {context.get('HbA1c')} %, glucose: {context.get('glucose')}, BP: {context.get('systolic_bp')}/{context.get('diastolic_bp')}",
        "",
        "Web search results (extract guidelines from these only; use the given URL as 'reference' for each):",
    ]
    for i, r in enumerate(web_results[:30], 1):
        title = r.get("title") or ""
        link = r.get("link") or ""
        snippet = r.get("snippet") or ""
        parts.append(f"[{i}] Title: {title}\nURL: {link}\nSnippet: {snippet}")
    parts.append(
        f"\nFrom the above search results, extract a JSON array of 10 to {max(10, top_k)} concrete lifestyle guidelines. "
        "Include multiple per category (diet, activity, sleep, behavior). "
        "Each object: \"category\", \"text\" (one actionable recommendation from the snippets), \"source\" (e.g. ADA 2024 or page title), "
        "\"reference\" (the URL from the result that supports this guideline). Use only information from the search results. "
        "Output only the JSON array, no other text or markdown."
    )
    user_prompt = "\n".join(parts)
    content = _call_llm(WEB_EXTRACT_SYSTEM_PROMPT, user_prompt)
    if content.startswith("```"):
        content = content.strip("`")
        lines = content.splitlines()
        if lines and lines[0].strip().lower().startswith("json"):
            content = "\n".join(lines[1:])
    try:
        raw = json.loads(content)
        if isinstance(raw, list):
            guidelines = []
            for g in raw[:top_k]:
                if isinstance(g, dict) and g.get("text"):
                    guidelines.append({
                        "category": g.get("category", "general"),
                        "text": g.get("text", ""),
                        "source": g.get("source", "web"),
                        "reference": g.get("reference", ""),
                    })
            return guidelines if guidelines else []
        return []
    except (json.JSONDecodeError, TypeError):
        return []


def build_user_prompt(context: Dict[str, Any], guidelines: List[Dict[str, Any]]) -> str:
    parts = ["Patient summary:"]
    for k, v in context.items():
        parts.append(f"- {k}: {v}")

    parts.append("\nRelevant guideline snippets (with references):")
    for g in guidelines:
        ref = g.get("reference") or g.get("source", "")
        parts.append(f"- [{g.get('category', 'general')}] {g.get('text', '')} (Ref: {ref})")

    parts.append(
        "\nWrite a JSON object with lifestyle recommendations under keys "
        "`diet`, `activity`, `sleep`, and `other`, each a list of plain-language suggestions."
    )
    return "\n".join(parts)


def generate_lifestyle_plan(context: Dict[str, Any], guidelines: List[Dict[str, Any]]) -> str:
    """
    Call a hosted LLM (e.g. Mistral or Grok) and return raw JSON string from the model.
    """
    prompt = build_user_prompt(context, guidelines)
    content = _call_llm(SYSTEM_PROMPT, prompt)

    # In case the model wraps JSON in markdown fences, strip them.
    content = content.strip()
    if content.startswith("```"):
        content = content.strip("`")
        # remove first line like "json"
        lines = content.splitlines()
        if lines and lines[0].strip().lower().startswith("json"):
            content = "\n".join(lines[1:])

    # Ensure it is JSON-parseable; if not, wrap into a simple structure.
    try:
        json.loads(content)
        return content
    except json.JSONDecodeError:
        fallback = {
            "diet": [content],
            "activity": [],
            "sleep": [],
            "other": [],
        }
        return json.dumps(fallback)

