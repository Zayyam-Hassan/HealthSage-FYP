"""
Web search for guideline retrieval. Uses Serper (Google Search API).
Set SERPER_API_KEY in .env to enable. https://serper.dev
"""
from __future__ import annotations

import os
from typing import Any, Dict, List

import httpx

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

SERPER_API_KEY = os.getenv("SERPER_API_KEY", "")
SERPER_URL = "https://google.serper.dev/search"


def search_web(query: str, num: int = 8) -> List[Dict[str, Any]]:
    """
    Run a web search and return list of {title, link, snippet}.
    Returns [] if SERPER_API_KEY is missing or request fails.
    """
    if not SERPER_API_KEY:
        return []
    payload = {"q": query, "num": num}
    headers = {"X-API-KEY": SERPER_API_KEY, "Content-Type": "application/json"}
    try:
        with httpx.Client(timeout=15.0) as client:
            resp = client.post(SERPER_URL, headers=headers, json=payload)
            resp.raise_for_status()
            data = resp.json()
    except Exception:
        return []
    organic = data.get("organic") or []
    return [
        {"title": o.get("title", ""), "link": o.get("link", ""), "snippet": o.get("snippet", "")}
        for o in organic
        if o.get("link")
    ]


def build_guideline_search_queries(context: Dict[str, Any]) -> List[str]:
    """Build search queries for diabetes lifestyle guidelines (ADA, diet, activity, sleep, etc.)."""
    queries = [
        "ADA American Diabetes Association Standards of Care diabetes diet nutrition 2024",
        "ADA diabetes physical activity exercise guidelines",
        "ADA diabetes lifestyle sleep stress smoking cessation guidelines",
        "diabetes medical nutrition therapy carbohydrate guidelines site:diabetesjournals.org OR site:diabetes.org",
    ]
    return queries


def fetch_web_results_for_guidelines(context: Dict[str, Any], max_results_per_query: int = 6) -> List[Dict[str, Any]]:
    """
    Run multiple web searches for guideline-related queries and return combined results.
    Each item: {title, link, snippet}.
    """
    queries = build_guideline_search_queries(context)
    seen_links = set()
    combined = []
    for q in queries:
        results = search_web(q, num=max_results_per_query)
        for r in results:
            link = (r.get("link") or "").strip()
            if link and link not in seen_links:
                seen_links.add(link)
                combined.append(r)
    return combined
