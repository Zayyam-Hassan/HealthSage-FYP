from typing import Any, Dict, List

from .llm_engine import (
    LLM_API_KEY,
    extract_guidelines_from_web_results,
    fetch_guidelines_for_patient,
)
from .web_search import SERPER_API_KEY, fetch_web_results_for_guidelines

# Multiple ADA guidelines per category with full references (fallback when LLM unavailable).
# References: ADA Standards of Medical Care in Diabetes—2024, Diabetes Care 2024;47(Suppl 1).
_STATIC_GUIDELINES: List[Dict[str, Any]] = [
    # Diet – multiple ADA guidelines
    {
        "source": "ADA 2024",
        "category": "diet",
        "text": "Encourage a Mediterranean-style or similar eating pattern rich in vegetables, whole grains, legumes, nuts, and olive oil.",
        "reference": "ADA Standards of Medical Care in Diabetes—2024, Section 5: Facilitating Positive Health Behaviors and Well-being. Diabetes Care 2024;47(Suppl 1):S77–S110.",
    },
    {
        "source": "ADA 2024",
        "category": "diet",
        "text": "Limit or avoid sugary drinks and ultra-processed foods; emphasize minimally processed whole foods.",
        "reference": "ADA Standards of Medical Care in Diabetes—2024, Section 5. Diabetes Care 2024;47(Suppl 1):S77–S110.",
    },
    {
        "source": "ADA 2024",
        "category": "diet",
        "text": "Individualize carbohydrate intake using glycemic index/load and portion control to improve postprandial glucose.",
        "reference": "ADA Standards of Medical Care in Diabetes—2024, Section 5 (Medical Nutrition Therapy). Diabetes Care 2024;47(Suppl 1):S77–S110.",
    },
    {
        "source": "ADA 2024",
        "category": "diet",
        "text": "Recommend adequate dietary fiber (at least 14 g per 1,000 kcal) from vegetables, legumes, and whole grains.",
        "reference": "ADA Standards of Medical Care in Diabetes—2024, Section 5. Diabetes Care 2024;47(Suppl 1):S77–S110.",
    },
    {
        "source": "ADA 2024",
        "category": "diet",
        "text": "For weight management, reduce energy intake while maintaining a healthful eating pattern; avoid restrictive fad diets.",
        "reference": "ADA Standards of Medical Care in Diabetes—2024, Section 8: Obesity and Weight Management. Diabetes Care 2024;47(Suppl 1):S126–S132.",
    },
    # Activity – multiple ADA guidelines
    {
        "source": "ADA 2024",
        "category": "activity",
        "text": "Aim for at least 150 minutes per week of moderate-intensity aerobic activity, spread over at least 3 days with no more than 2 consecutive days without activity.",
        "reference": "ADA Standards of Medical Care in Diabetes—2024, Section 5 (Physical Activity). Diabetes Care 2024;47(Suppl 1):S77–S110.",
    },
    {
        "source": "ADA 2024",
        "category": "activity",
        "text": "Add 2–3 sessions per week of resistance exercise on nonconsecutive days for additional glycemic and strength benefits.",
        "reference": "ADA Standards of Medical Care in Diabetes—2024, Section 5. Diabetes Care 2024;47(Suppl 1):S77–S110.",
    },
    {
        "source": "ADA 2024",
        "category": "activity",
        "text": "Reduce sedentary time; break up prolonged sitting with short bouts of light activity every 30 minutes when possible.",
        "reference": "ADA Standards of Medical Care in Diabetes—2024, Section 5. Diabetes Care 2024;47(Suppl 1):S77–S110.",
    },
    {
        "source": "ADA 2024",
        "category": "activity",
        "text": "For older adults, include flexibility and balance training (e.g., yoga, tai chi) to reduce fall risk.",
        "reference": "ADA Standards of Medical Care in Diabetes—2024, Section 5. Diabetes Care 2024;47(Suppl 1):S77–S110.",
    },
    # Sleep
    {
        "source": "ADA 2024",
        "category": "sleep",
        "text": "Promote consistent sleep schedules and good sleep hygiene, targeting 7–9 hours of quality sleep per night.",
        "reference": "ADA Standards of Medical Care in Diabetes—2024, Section 5 (Facilitating Positive Health Behaviors). Diabetes Care 2024;47(Suppl 1):S77–S110.",
    },
    {
        "source": "ADA 2024",
        "category": "sleep",
        "text": "Address sleep disorders (e.g., obstructive sleep apnea) when suspected; poor sleep is linked to worse glycemic control.",
        "reference": "ADA Standards of Medical Care in Diabetes—2024, Section 5. Diabetes Care 2024;47(Suppl 1):S77–S110.",
    },
    # Behavior
    {
        "source": "ADA 2024",
        "category": "behavior",
        "text": "Advise complete smoking cessation and offer counseling and pharmacotherapy as needed; avoid e-cigarettes for cessation.",
        "reference": "ADA Standards of Medical Care in Diabetes—2024, Section 5 (Smoking Cessation). Diabetes Care 2024;47(Suppl 1):S77–S110.",
    },
    {
        "source": "ADA 2024",
        "category": "behavior",
        "text": "Recommend stress-management techniques such as mindfulness, relaxation exercises, or counseling to support self-care and well-being.",
        "reference": "ADA Standards of Medical Care in Diabetes—2024, Section 5 (Psychosocial Care). Diabetes Care 2024;47(Suppl 1):S77–S110.",
    },
    {
        "source": "ADA 2024",
        "category": "behavior",
        "text": "Limit alcohol intake; if consumed, do so in moderation with food and with awareness of hypoglycemia risk.",
        "reference": "ADA Standards of Medical Care in Diabetes—2024, Section 5. Diabetes Care 2024;47(Suppl 1):S77–S110.",
    },
]


def retrieve_guidelines(context: Dict[str, Any], top_k: int = 20) -> List[Dict[str, Any]]:
    """
    Retrieve evidence-based lifestyle guidelines relevant to this patient.
    - If SERPER_API_KEY and LLM_API_KEY are set: run web search for ADA/diabetes guidelines,
      then LLM extracts guidelines from search results (with real URLs as references).
    - Else if LLM_API_KEY only: LLM generates guidelines from its knowledge.
    - Else: return static ADA guidelines.
    """
    # 1) Web search + LLM extract (real lookup from the web)
    if SERPER_API_KEY and LLM_API_KEY:
        try:
            web_results = fetch_web_results_for_guidelines(context, max_results_per_query=6)
            if web_results:
                guidelines = extract_guidelines_from_web_results(
                    web_results, context, top_k=max(top_k, 16)
                )
                if guidelines:
                    return guidelines[:top_k]
        except Exception:
            pass
    # 2) LLM-only (no search)
    if LLM_API_KEY:
        try:
            guidelines = fetch_guidelines_for_patient(context, top_k=max(top_k, 16))
            if guidelines:
                return guidelines[:top_k]
        except Exception:
            pass
    # 3) Static fallback
    return _STATIC_GUIDELINES[:top_k]

