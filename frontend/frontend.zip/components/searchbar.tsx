import { icons } from "@/constants/icons";
import React, { useState } from "react";
import { Image, TextInput, View, TouchableOpacity, Text } from "react-native";

interface SearchBarProps {
  placeholder?: string;
  onSearch?: (text: string) => void;
  value?: string;
  onChangeText?: (text: string) => void;
  className?: string;
}

const SearchBar: React.FC<SearchBarProps> = ({
  placeholder = "Search...",
  onSearch,
  value: controlledValue,
  onChangeText: controlledOnChangeText,
  className = "",
}) => {
  const [searchText, setSearchText] = useState("");

  const value = controlledValue !== undefined ? controlledValue : searchText;
  const handleChangeText = (text: string) => {
    if (controlledOnChangeText) {
      controlledOnChangeText(text);
    } else {
      setSearchText(text);
    }
  };

  const handleSearch = () => {
    if (onSearch) {
      onSearch(value);
    }
  };

  return (
    <View className={`flex-row items-center bg-bg-secondary rounded-full px-4 py-3 shadow-sm ${className}`.trim()}>
      <Image
        source={icons.search}
        className="w-5 h-5"
        resizeMode="contain"
        tintColor="#faad9e"
      />
      <TextInput
        placeholder={placeholder}
        value={value}
        onChangeText={handleChangeText}
        placeholderTextColor="#9CA3AF"
        className="flex-1 ml-3 text-base text-text"
        returnKeyType="search"
        onSubmitEditing={handleSearch}
      />
      {value.length > 0 && (
        <TouchableOpacity onPress={() => handleChangeText("")} className="ml-2">
          <Text className="text-text-secondary text-sm">✕</Text>
        </TouchableOpacity>
      )}
    </View>
  );
};

export default SearchBar;
