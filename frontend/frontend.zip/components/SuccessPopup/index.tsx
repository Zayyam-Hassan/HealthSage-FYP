import React, { useEffect, useRef } from 'react';
import { View, Text, TouchableOpacity, Animated, Modal, Dimensions } from 'react-native';

interface SuccessPopupProps {
  visible: boolean;
  message: string;
  onClose: () => void;
  duration?: number;
}

const { width } = Dimensions.get('window');

const SuccessPopup: React.FC<SuccessPopupProps> = ({
  visible,
  message,
  onClose,
  duration = 3000,
}) => {
  const scaleAnim = useRef(new Animated.Value(0)).current;
  const opacityAnim = useRef(new Animated.Value(0)).current;
  const backdropOpacity = useRef(new Animated.Value(0)).current;
  const iconScale = useRef(new Animated.Value(0)).current;
  const iconRotation = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (visible) {
      // Reset and animate in sequence for smooth effect
      scaleAnim.setValue(0);
      opacityAnim.setValue(0);
      backdropOpacity.setValue(0);
      iconScale.setValue(0);
      iconRotation.setValue(0);

      // Backdrop fade in
      Animated.timing(backdropOpacity, {
        toValue: 1,
        duration: 300,
        useNativeDriver: true,
      }).start();

      // Icon animation with bounce
      Animated.sequence([
        Animated.spring(iconScale, {
          toValue: 1.2,
          useNativeDriver: true,
          tension: 50,
          friction: 3,
        }),
        Animated.spring(iconScale, {
          toValue: 1,
          useNativeDriver: true,
          tension: 50,
          friction: 5,
        }),
      ]).start();

      // Icon rotation
      Animated.timing(iconRotation, {
        toValue: 1,
        duration: 400,
        useNativeDriver: true,
      }).start();

      // Card animation with spring
      Animated.parallel([
        Animated.spring(scaleAnim, {
          toValue: 1,
          useNativeDriver: true,
          tension: 65,
          friction: 8,
        }),
        Animated.timing(opacityAnim, {
          toValue: 1,
          duration: 300,
          useNativeDriver: true,
        }),
      ]).start();

      // Auto dismiss
      const timer = setTimeout(() => {
        handleClose();
      }, duration);

      return () => clearTimeout(timer);
    } else {
      // Reset animations
      scaleAnim.setValue(0);
      opacityAnim.setValue(0);
      backdropOpacity.setValue(0);
      iconScale.setValue(0);
      iconRotation.setValue(0);
    }
  }, [visible]);

  const handleClose = () => {
    Animated.parallel([
      Animated.timing(scaleAnim, {
        toValue: 0.8,
        duration: 200,
        useNativeDriver: true,
      }),
      Animated.timing(opacityAnim, {
        toValue: 0,
        duration: 200,
        useNativeDriver: true,
      }),
      Animated.timing(backdropOpacity, {
        toValue: 0,
        duration: 200,
        useNativeDriver: true,
      }),
    ]).start(() => {
      onClose();
    });
  };

  const iconRotationInterpolate = iconRotation.interpolate({
    inputRange: [0, 1],
    outputRange: ['-180deg', '0deg'],
  });

  return (
    <Modal
      visible={visible}
      transparent
      animationType="none"
      onRequestClose={handleClose}
      statusBarTranslucent
    >
      <Animated.View
        style={{
          opacity: backdropOpacity,
        }}
        className="flex-1 items-center justify-center bg-black/50 px-6"
      >
        <Animated.View
          style={{
            transform: [
              { scale: scaleAnim },
              { translateY: scaleAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [50, 0],
                })},
            ],
            opacity: opacityAnim,
          }}
          className="bg-white rounded-3xl p-8 items-center shadow-2xl max-w-sm w-full border border-primary/10"
        >
          {/* Success Icon with Animation */}
          <Animated.View
            style={{
              transform: [
                { scale: iconScale },
                { rotate: iconRotationInterpolate },
              ],
            }}
            className="w-24 h-24 bg-primary/20 rounded-full items-center justify-center mb-6 shadow-lg"
          >
            <View className="w-20 h-20 bg-primary/15 rounded-full items-center justify-center">
              <Text className="text-6xl">✨</Text>
            </View>
          </Animated.View>

          {/* Success Title */}
          <Text className="text-2xl font-bold text-text text-center mb-3">
            Awesome! 🎉
          </Text>

          {/* Message */}
          <Text className="text-base text-text-secondary text-center mb-8 leading-6 px-2">
            {message}
          </Text>

          {/* Close Button with gradient effect */}
          <TouchableOpacity
            onPress={handleClose}
            className="bg-primary rounded-2xl px-10 py-4 w-full items-center shadow-lg active:opacity-80"
            activeOpacity={0.8}
            style={{
              shadowColor: '#faad9e',
              shadowOffset: { width: 0, height: 4 },
              shadowOpacity: 0.3,
              shadowRadius: 8,
              elevation: 8,
            }}
          >
            <Text className="text-white font-bold text-base">Got it!</Text>
          </TouchableOpacity>
        </Animated.View>
      </Animated.View>
    </Modal>
  );
};

export default SuccessPopup;

