import React from 'react';
import { View, Text, TouchableOpacity, Image } from 'react-native';
import { useRouter } from 'expo-router';
import { images } from '@/constants/images';

interface HeaderProps {
  title?: string;
  showBack?: boolean;
  rightActions?: React.ReactNode;
  onBackPress?: () => void;
  showLogo?: boolean;
  className?: string;
}

const Header: React.FC<HeaderProps> = ({
  title,
  showBack = false,
  rightActions,
  onBackPress,
  showLogo = false,
  className = '',
}) => {
  const router = useRouter();

  const handleBackPress = () => {
    if (onBackPress) {
      onBackPress();
    } else {
      router.back();
    }
  };

  return (
    <View
      className={`
        flex-row
        items-center
        justify-between
        px-4
        py-3
        bg-background
        ${className}
      `.trim().replace(/\s+/g, ' ')}
    >
      <View className="flex-row items-center flex-1">
        {showBack && (
          <TouchableOpacity
            onPress={handleBackPress}
            className="mr-3"
            hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
          >
            <Text className="text-2xl text-text">←</Text>
          </TouchableOpacity>
        )}
        {showLogo && !title && (
          <Image
            source={images.healthsageLogo}
            className="w-32 h-8"
            resizeMode="contain"
          />
        )}
        {title && (
          <Text className="text-xl font-bold text-text flex-1" numberOfLines={1}>
            {title}
          </Text>
        )}
      </View>
      {rightActions && <View className="flex-row items-center">{rightActions}</View>}
    </View>
  );
};

export default Header;

