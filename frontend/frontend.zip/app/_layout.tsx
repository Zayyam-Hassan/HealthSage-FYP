import { Stack } from "expo-router";
import './global.css';

export default function RootLayout() {
  return (
    <Stack
      screenOptions={{
        headerShown: false,
      }}
      initialRouteName="(auth)"
    >
      <Stack.Screen name="(auth)" />
      <Stack.Screen name="(tabs)" />
      <Stack.Screen name="onboarding" />
      <Stack.Screen name="assessment" />
      <Stack.Screen name="chatbot" />
      <Stack.Screen name="notifications" />
      <Stack.Screen name="help-support" />
      <Stack.Screen name="dashboard" />
      <Stack.Screen name="movies/[id]" />
      <Stack.Screen name="risk" />
      <Stack.Screen name="patients" />
      <Stack.Screen name="patients/[id]" />
      <Stack.Screen name="patients/new" />
      <Stack.Screen name="patients/[id]/edit" />
      <Stack.Screen name="medications" />
      <Stack.Screen name="medications/[id]" />
      <Stack.Screen name="compatibility" />
      <Stack.Screen name="appointments" />
      <Stack.Screen name="appointments/[id]" />
      <Stack.Screen name="appointments/book" />
      <Stack.Screen name="psychiatrist" />
      <Stack.Screen name="psychiatrist/[id]" />
      <Stack.Screen name="reports" />
      <Stack.Screen name="reports/[id]" />
    </Stack>
  );
}
