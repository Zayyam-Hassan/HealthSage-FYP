import fs from 'fs';
import path from 'path';

type ReportSection = {
  heading: string;
  body: string;
};

function escapePdfText(value: string) {
  return value
    .replace(/\\/g, '\\\\')
    .replace(/\(/g, '\\(')
    .replace(/\)/g, '\\)');
}

function wrapText(text: string, maxChars = 82) {
  const words = text.replace(/\s+/g, ' ').trim().split(' ');
  const lines: string[] = [];
  let current = '';

  for (const word of words) {
    const candidate = current ? `${current} ${word}` : word;
    if (candidate.length <= maxChars) {
      current = candidate;
    } else {
      if (current) {
        lines.push(current);
      }
      current = word;
    }
  }

  if (current) {
    lines.push(current);
  }

  return lines.length > 0 ? lines : [''];
}

function buildContentStream(title: string, sections: ReportSection[]) {
  const commands: string[] = [];
  let y = 760;

  commands.push('BT');
  commands.push('/F1 20 Tf');
  commands.push(`50 ${y} Td`);
  commands.push(`(${escapePdfText(title)}) Tj`);
  commands.push('ET');

  y -= 32;

  for (const section of sections) {
    if (y < 80) {
      break;
    }

    commands.push('BT');
    commands.push('/F1 13 Tf');
    commands.push(`50 ${y} Td`);
    commands.push(`(${escapePdfText(section.heading)}) Tj`);
    commands.push('ET');
    y -= 20;

    const lines = wrapText(section.body);
    for (const line of lines) {
      if (y < 60) {
        break;
      }
      commands.push('BT');
      commands.push('/F1 11 Tf');
      commands.push(`58 ${y} Td`);
      commands.push(`(${escapePdfText(line)}) Tj`);
      commands.push('ET');
      y -= 16;
    }

    y -= 8;
  }

  return commands.join('\n');
}

function buildPdfBuffer(title: string, sections: ReportSection[]) {
  const content = buildContentStream(title, sections);
  const objects = [
    '1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj',
    '2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj',
    '3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >> endobj',
    '4 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> endobj',
    `5 0 obj << /Length ${Buffer.byteLength(content, 'utf8')} >> stream\n${content}\nendstream endobj`,
  ];

  const header = '%PDF-1.4\n';
  const body = `${objects.join('\n')}\n`;
  let offset = header.length;
  const offsets = ['0000000000 65535 f '];

  for (const object of objects) {
    offsets.push(`${offset.toString().padStart(10, '0')} 00000 n `);
    offset += Buffer.byteLength(`${object}\n`, 'utf8');
  }

  const xrefOffset = offset;
  const xref = `xref\n0 ${objects.length + 1}\n${offsets.join('\n')}\n`;
  const trailer = `trailer << /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`;

  return Buffer.from(`${header}${body}${xref}${trailer}`, 'utf8');
}

export async function writeReportPdf(
  reportId: string,
  title: string,
  sections: ReportSection[],
) {
  const reportsDir = path.join(process.cwd(), 'generated-reports');
  await fs.promises.mkdir(reportsDir, { recursive: true });
  const filePath = path.join(reportsDir, `${reportId}.pdf`);
  await fs.promises.writeFile(filePath, buildPdfBuffer(title, sections));
  return filePath;
}
